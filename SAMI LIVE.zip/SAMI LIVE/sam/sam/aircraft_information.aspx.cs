﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace sam
{
    public partial class aircraft_information : System.Web.UI.Page
    {

        private DbInterface db = new DbInterface();
        private DbInterface db1 = new DbInterface();
        private DbInterface db2 = new DbInterface();
        private DbInterface db3 = new DbInterface();
        protected Admin_User Usr = new Admin_User();        
        string sql = string.Empty;
        string sql1 = string.Empty;
        string sql2 = string.Empty;
        string sql3 = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySql.Data.MySqlClient.MySqlCommand cmd1 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd2 = null;
        MySql.Data.MySqlClient.MySqlCommand cmd3 = null;
        MySqlDataReader dr = null;
        MySqlDataReader d1 = null;
        MySqlDataReader dr2 = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            hideMenu();
            Fill_Aircraft_model();
            FillGrid();
            Fill_fee_Contract();
            Fill_Trainer_hours();
            ddl_fee.Attributes.Add("disabled", "disabled");
            ddl_trainer_hour.Attributes.Add("disabled", "disabled");            
        }

        private void Fill_Trainer_hours()
        {
            try
            {
                ddl_trainer.Items.Clear();
                ddl_trainer_hour.Items.Clear();

                ListItem item_ddl_trainer = new ListItem();
                ListItem item_ddl_trainer_hour = new ListItem();

                item_ddl_trainer = new ListItem("PLEASE SELECT", "0");
                item_ddl_trainer_hour = new ListItem("PLEASE SELECT", "0");

                ddl_trainer.Items.Add(item_ddl_trainer);
                ddl_trainer_hour.Items.Add(item_ddl_trainer_hour);

                sql = "SELECT fld_id,fld_trainer_name,fld_hours FROM table_trainers WHERE fld_status ='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item_ddl_trainer = new ListItem(dr["fld_trainer_name"].ToString(), dr["fld_id"].ToString());
                    item_ddl_trainer_hour = new ListItem(dr["fld_hours"].ToString(), dr["fld_id"].ToString());

                    ddl_trainer.Items.Add(item_ddl_trainer);
                    ddl_trainer_hour.Items.Add(item_ddl_trainer_hour);
                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void Fill_fee_Contract()
        {
            try
            {
                ddl_contract.Items.Clear();
                ddl_fee.Items.Clear();

                ListItem item_contract = new ListItem();
                ListItem item_fee = new ListItem();

                item_contract = new ListItem("PLEASE SELECT", "0");
                item_fee = new ListItem("PLEASE SELECT", "0");

                ddl_contract.Items.Add(item_contract);
                ddl_fee.Items.Add(item_fee);

                sql = "SELECT fld_id,fld_contract,fld_fee FROM table_contract WHERE fld_status ='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item_contract = new ListItem(dr["fld_contract"].ToString(), dr["fld_id"].ToString());
                    item_fee = new ListItem(dr["fld_fee"].ToString(), dr["fld_id"].ToString());

                    ddl_contract.Items.Add(item_contract);
                    ddl_fee.Items.Add(item_fee);
                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void Fill_Aircraft_model()
        {
            try
            {
                ddl_add_aircraft_model.Items.Clear();
                ddl_manufacturing_year.Items.Clear();
                ddl_hours.Items.Clear();
                ListItem item_name = new ListItem();
                ListItem item_year = new ListItem();
                ListItem item_hour = new ListItem();
                item_name = new ListItem("PLEASE SELECT", "0");
                item_year = new ListItem("PLEASE SELECT", "0");
                item_hour = new ListItem("PLEASE SELECT", "0");
                ddl_add_aircraft_model.Items.Add(item_name);
                ddl_manufacturing_year.Items.Add(item_year);
                ddl_hours.Items.Add(item_hour);

                sql = "SELECT fld_id,fld_aircraft_name,fld_manufacturing_year,fld_hours,fld_status "+
                    " FROM table_aircraft_models WHERE fld_status ='1' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item_name = new ListItem(dr["fld_aircraft_name"].ToString(), dr["fld_id"].ToString());
                    ddl_add_aircraft_model.Items.Add(item_name);
                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }

        private void Fill_year_hour(string ID)
        {
            try
            {
                ddl_add_aircraft_model.SelectedValue = ID;
                ddl_manufacturing_year.Items.Clear();
                ddl_hours.Items.Clear();
               
                ListItem item_year = new ListItem();
                ListItem item_hour = new ListItem();
               
                ddl_manufacturing_year.Items.Add(item_year);
                ddl_hours.Items.Add(item_hour);

                sql = "SELECT fld_id,fld_aircraft_name,fld_manufacturing_year,fld_hours,fld_status " +
                    " FROM table_aircraft_models WHERE fld_status ='1' AND fld_id='" + ID + "' ORDER BY fld_id ;";
                MySqlCommand cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                while (dr.Read())
                {
                    item_year = new ListItem(dr["fld_manufacturing_year"].ToString(), dr["fld_id"].ToString());
                    item_hour = new ListItem(dr["fld_hours"].ToString(), dr["fld_id"].ToString());

                    ddl_manufacturing_year.Items.Add(item_year);
                    ddl_hours.Items.Add(item_hour);

                    ddl_manufacturing_year.SelectedValue = dr["fld_id"].ToString();
                    ddl_hours.SelectedValue = dr["fld_id"].ToString();
                                        
                    ddl_manufacturing_year.Attributes.Add("disabled", "disabled");
                    ddl_hours.Attributes.Add("disabled", "disabled");

                }
                dr.Close();

            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                db.Close();
            }
        }
        
        protected void btn_change_dropdown(object sender, EventArgs e)
        {
            Fill_year_hour(hid_aircraft_id.Value);
        }

        protected void btn_selectinfo(object sender, EventArgs e)
        {
            string aids = string.Empty;
            string trainer_id = string.Empty;
            try
            {
                trainer_id = hid_trainer_id.Value;
                sql3 = "INSERT INTO table_fee_info(" +
                   "fld_air_craft_id," +
                   "fld_contract_id," +
                   "fld_status ) VALUES(" +
                   "@fld_air_craft_id," +
                   "@fld_contract_id," +
                   "1)";
                cmd3 = new MySqlCommand(sql3);
                cmd3.Parameters.AddWithValue("@fld_air_craft_id", hid_aircraft_id.Value);
                cmd3.Parameters.AddWithValue("@fld_contract_id", hid_contract_id.Value);
                db3.Execute(cmd3);

                sql = "Update table_aircraft_models set fld_status=@status where fld_id = @_aircraft_id";
                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@status", '2');
                cmd.Parameters.AddWithValue("@_aircraft_id", hid_aircraft_id.Value);
                db.Execute(cmd);

                sql1 = "Update table_trainers set fld_aircraft_id=@_aircraft_id ,fld_status=@_status  where fld_id=@_trainer_id";
                cmd1 = new MySqlCommand(sql1);
                cmd1.Parameters.AddWithValue("@_status", '0');
                cmd1.Parameters.AddWithValue("@_aircraft_id", hid_aircraft_id.Value);
                cmd1.Parameters.AddWithValue("@_trainer_id", trainer_id);
                db1.Execute(cmd1);

            }
            finally
            {
                db.Close();
                db1.Close();
                db3.Close();
                Response.Redirect("aircraft_information.aspx");
            }
            
        }

        protected void btn_delete(object sender, EventArgs e)
        {
            string aid_cid = string.Empty;
            string aircraftid = string.Empty;
            string info_id = string.Empty;
            string[] a_f;
            
            try
            {
                aid_cid = hid_cid.Value;
                a_f = aid_cid.Split(',');
                foreach (string str in a_f)
                {
                    aircraftid = a_f[0];
                    info_id = a_f[1];
                }

                sql = "Update table_aircraft_models set fld_status=@status where fld_id = @_aircraft_id";
                cmd = new MySqlCommand(sql);
                cmd.Parameters.AddWithValue("@status", '1');
                cmd.Parameters.AddWithValue("@_aircraft_id", aircraftid);
                db.Execute(cmd);

                sql1 = "Update table_fee_info set fld_status=@_status where fld_id = @_id";
                cmd1 = new MySqlCommand(sql1);
                cmd1.Parameters.AddWithValue("@_status", "0");
                cmd1.Parameters.AddWithValue("@_id", info_id);
                db1.Execute(cmd1);

                sql2 = "Update table_trainers set fld_aircraft_id=@_aircraft_reset_value , fld_status=@_status where fld_aircraft_id = @_aircraft_id";
                cmd2 = new MySqlCommand(sql2);
                cmd2.Parameters.AddWithValue("@_status", '1');
                cmd2.Parameters.AddWithValue("@_aircraft_reset_value", '0');
                cmd2.Parameters.AddWithValue("@_aircraft_id", aircraftid);
                db2.Execute(cmd2);

            }
            finally
            {
                db.Close();
                db1.Close();
                db2.Close();
                Response.Redirect("aircraft_information.aspx");
            }
            
        }

        private void FillGrid()
        {
            string aids = string.Empty;
            StringBuilder sb = new StringBuilder();
            try
            {
                
                sql = "SELECT a.fld_id as aid, " +
                    " c.fld_id as cid ," +
                    " i.fld_id as fId ," +
                    " a.fld_aircraft_name as aircraft_name, " +
                    " a.fld_manufacturing_year as manufacturing_year," +
                    " a.fld_hours as hours," +
                    " a.fld_status as astatus, " +
                    " t.fld_hours as t_hours, " +
                    " t.fld_trainer_name as trainer_name, " +
                    " t.fld_status as tstatus, " +
                    " c.fld_contract as contract," +
                    " c.fld_aircraft_id as aircraft_id," +
                    " c.fld_fee as fee" +
                    " FROM table_aircraft_models a "+
                    " INNER JOIN table_contract c "+
                    " INNER JOIN table_fee_info i "+
                    " INNER JOIN table_trainers t " +
                    " ON a.fld_id = i.fld_air_craft_id  " +
                    " AND c.fld_id = i.fld_contract_id  " +
                    " AND a.fld_id = t.fld_aircraft_id  " +
                    " WHERE a.fld_status ='2' AND i.fld_status ='1' AND t.fld_status ='0';";

                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblInfo\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>AIRCRAFT NAME</th>" +
                    "<th>MANUFACTURING YEAR</th>" +
                    "<th>HOURS IN AIR</th>" +
                    "<th>CONTRACT</th>" +
                    "<th>FEE (GBP)</th>" +
                    "<th>TRAINER</th>" +
                    "<th>TRAINING PERIOD(HOURS)</th>" +
                    "<th>ACTION</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    aids += "";
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["aircraft_name"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["manufacturing_year"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["hours"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["contract"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["fee"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["trainer_name"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["t_hours"].ToString() + "</td>" +                    
                    "<td style=\"padding-left:8px;\">"+
                    "<a href=\"#\">"+
                    "<img src=\"img/delete_icon.png\" height=\"26px\" width=\"26px\" border=\"0\" "+
                    "alt=\"Delete\" title=\"Delete\" onclick=\"DeleteInfo('" + dr["aid"].ToString() + "," + dr["fId"].ToString() + "')\" >" +
                    //"alt=\"Delete\" title=\"Delete\" onclick=\"DeleteInfo('" + dr["fId"].ToString() + "')\" >" +
                    "</a>"+
                    "</td>" +                    
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" style=\"colour:red\" >No record found.</h3>");
                }

                lbl_AircraftGrid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }

        private void hideMenu()
        {
            HtmlGenericControl li_aircraft_info = (HtmlGenericControl)Master.FindControl("li_aircraft_info");
            HtmlGenericControl li_fee_info = (HtmlGenericControl)Master.FindControl("li_fee_info");
            HtmlGenericControl li_aircraft_availability = (HtmlGenericControl)Master.FindControl("li_aircraft_availability");
            HtmlGenericControl li_trainer_information = (HtmlGenericControl)Master.FindControl("li_trainer_information");   
            HtmlGenericControl li_aircraft_login = (HtmlGenericControl)Master.FindControl("li_aircraft_login");
            HtmlGenericControl li_aircraft_logout = (HtmlGenericControl)Master.FindControl("li_aircraft_logout");

            li_aircraft_info.Visible = true;
            li_fee_info.Visible = true;
            li_aircraft_availability.Visible = true;
            li_trainer_information.Visible = true;
            li_aircraft_login.Visible = false;
            li_aircraft_logout.Visible = true;
        }

        
        
    }
}