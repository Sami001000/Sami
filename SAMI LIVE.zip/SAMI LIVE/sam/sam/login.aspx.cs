﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sam
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void btn_Login_Click(object sender, EventArgs e)
        {
            if (txt_Username.Text == "")
            {
                lbl_error.InnerText = "Enter UserName";
            }
            else if (txt_password.Text == "")
            {
                lbl_error.InnerText = "Enter Password";
            }
            else
            {
                if (txt_Username.Text == "sam" && txt_password.Text == "sam987")
                {
                    Response.Redirect("aircraft_information.aspx");
                    //lbl_error.InnerText = "Login Succesfull";
                }
                else
                {
                    lbl_error.InnerText = "Invalid Name or Password";
                }
            }

        }
    }
}