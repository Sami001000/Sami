using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data.MySqlClient;


public class Admin_User
{
    DbInterface db = new DbInterface ();

    protected string user_id;
    protected string username;
    protected string password;
    protected int status;
   
    public string UserId
    {
        get
        {
            return user_id;
        }
        set
        {
            user_id = value;
        }
    }
    
    public int Status
    {
        get
        {
            return status;
        }
        set
        {
            status = value;
        }
    }

    public string Username
    {
        get
        {
            return username;
        }
        set
        {
            username = value;
        }
    }

    public string Password
    {
        get
        {
            return password;
        }
        set
        {
            password = value;
        }
    }

   

}

