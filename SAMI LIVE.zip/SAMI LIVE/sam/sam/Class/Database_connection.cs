using System;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;

/// <summary>
/// Summary description for dbi.
/// </summary>
public class DbInterface
{
    MySqlConnection m_Conn = new MySqlConnection();

    protected int m_dLine;
    protected string m_strFile;

    public DbInterface(string strConn)
    {
        string strConnection = strConn;
        StackFrame CallStack = new StackFrame(1, true);

        m_dLine = CallStack.GetFileLineNumber();
        m_strFile = CallStack.GetFileName();

        m_Conn = new MySqlConnection(strConnection);

        if (m_Conn == null)
            throw (new Exception("New connection is null"));
    }
    
    public DbInterface()
    {
        string strConnection = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        StackFrame CallStack = new StackFrame(1, true);

        m_dLine = CallStack.GetFileLineNumber();
        m_strFile = CallStack.GetFileName();

        m_Conn = new MySqlConnection(strConnection);

        if (m_Conn == null)
            throw (new Exception("New connection is null"));

    }

    ~DbInterface()
    {
        Close();
    }

    private MySqlConnection Open()
    {
        if (m_Conn.State != ConnectionState.Open)
            m_Conn.Open();

        if (m_Conn.State != ConnectionState.Open)
            throw (new Exception("Tried to open connection, was unable to complete."));

        return m_Conn;
    }

    public void Close()
    {
        try
        {
            if (m_Conn != null)
                m_Conn.Close();
            else
                logit("Connection was null on an attempt to close.\t(" +
                    m_strFile + " : " + m_dLine + ")");
        }
        catch (Exception ex)
        {
            logit("Exception thrown: " + ex.Message);
            logit(ex.StackTrace);
            logit("m_Conn = " + m_Conn.State);
            logit("");
        }
    }

    public MySqlDataAdapter SelectAdapter(string strQuery)
    {
        Open();
        MySqlDataAdapter da = new MySqlDataAdapter(strQuery, m_Conn);
        return da;
    }

   

    public string MySqlExecuteScalar(string strQuery)
    {
        Open();
        MySqlCommand cmd = new MySqlCommand(strQuery, m_Conn);
        string str = cmd.ExecuteScalar().ToString();
        Close();
        return str;
    }   

    public static string fixWhSpace(string strInput)
    {
        string Title = strInput;
        string[] t = strInput.Split();
        string res = string.Empty;

        foreach (string t1 in t)
        {
            res += t1;
        }

        return res;
    }

    public void logit(string strText)
    {
        string strFileName = ConfigurationManager.AppSettings["strLog"];

        if (false == File.Exists(strFileName))
        {
            FileStream fs = new FileStream(
                strFileName, FileMode.OpenOrCreate,
                FileAccess.ReadWrite);
            fs.Close();
        }

        StreamWriter sw = new StreamWriter(strFileName, true);
        sw.WriteLine(strText);
        sw.Flush();
        sw.Close();
    }
    

    public MySqlDataReader Read(MySqlCommand cmd)
    {
        Open();
        cmd.Connection = m_Conn;
        cmd.CommandType = CommandType.Text;
        MySqlDataReader dr;
        try
        {
            dr = cmd.ExecuteReader(System.Data.CommandBehavior.Default);
        }
        catch (MySqlException ex)
        {
            dr = cmd.ExecuteReader();
            logit("Exception thrown: " + ex.Message);
            logit(ex.StackTrace);
            logit("m_Conn = " + m_Conn.State);
            logit("");
        }
        return dr;
    }   

    public int Execute(MySqlCommand cmd)
    {
        Open();
        cmd.Connection = m_Conn;
        cmd.CommandType = CommandType.Text;
        return cmd.ExecuteNonQuery();
    }

    public DataSet GetDataSet(MySqlCommand cmd)
    {
        Open();
        cmd.Connection = m_Conn;
        cmd.CommandType = CommandType.Text;
        DataSet ds = new DataSet();        
        MySqlDataAdapter da = new MySqlDataAdapter();
        cmd.CommandType = CommandType.Text;        
        try
        {            
            da.SelectCommand = cmd;
            da.Fill(ds);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            Close();
            da.Dispose();
            cmd.Dispose();
        }
        return ds;
    }

    public DataTable GetDataTable(MySqlCommand cmd)
    {
        Open();
        cmd.Connection = m_Conn;
        cmd.CommandType = CommandType.Text;
        DataTable dt = new DataTable();
        MySqlDataAdapter da = new MySqlDataAdapter();
        cmd.CommandType = CommandType.Text;
        try
        {
            da.SelectCommand = cmd;
            da.Fill(dt);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            Close();
            da.Dispose();
            cmd.Dispose();
        }
        return dt;
    }



    public MySqlDataReader ReadQry(string strQuery)
    {
        Open();
        MySqlCommand cmd = new MySqlCommand(strQuery, m_Conn);
        MySqlDataReader dr;
        try
        {
            dr = cmd.ExecuteReader(System.Data.CommandBehavior.Default);
        }
        catch (MySqlException ex)
        {
            dr = cmd.ExecuteReader();
            logit("Exception thrown: " + ex.Message);
            logit(ex.StackTrace);
            logit("m_Conn = " + m_Conn.State);
            logit("");
        }
        return dr;
    }

    public MySqlDataAdapter SelectAdapterQry(string strQuery)
    {
        Open();
        MySqlDataAdapter da = new MySqlDataAdapter(strQuery, m_Conn);
        return da;
    }

    public int ExecuteQry(string strQuery)
    {
        Open();
        MySqlCommand cmd = new MySqlCommand(strQuery, m_Conn);
        return cmd.ExecuteNonQuery();
    }

    public string MySqlExecuteScalarQry(string strQuery)
    {
        Open();
        MySqlCommand cmd = new MySqlCommand(strQuery, m_Conn);
        string str = cmd.ExecuteScalar().ToString();
        Close();
        return str;
    }

    public DataSet GetDataSetQry(string strQuery)
    {
        MySqlDataAdapter daInput = SelectAdapterQry(strQuery);
        DataSet dsOutput = new DataSet();
        daInput.Fill(dsOutput);
        return dsOutput;
    }



    public static string fix(string strInput)
    {
        if (strInput == null)
            return "";
        strInput = strInput.Replace("\\", "\\\\");
        return strInput.Replace("'", "''").Trim();
    }

    public static string fixWithoutTrim(string strInput)
    {
        if (strInput == null)
            return "";
        strInput = strInput.Replace("\\", "\\\\");
        return strInput.Replace("'", "''");
    }

    public static string fixdate(DateTime dtInput)
    {
        string tmp = dtInput.ToString("yyyy-MM-dd HH:mm:ss");
        return tmp;
    }

    public static string fixdateshort(DateTime dtInput)
    {
        string tmp = dtInput.ToString("yyyy-MM-dd");
        return tmp;
    }

    public static string fixtime(DateTime dtInput)
    {
        string tmp = dtInput.ToString("HH:mm:ss");
        return tmp;
    }
    
    public static string formatCurrency(string amount)
    {
        try
        {
            decimal amountValue = Convert.ToDecimal(amount);
            return "$" + amountValue.ToString("##,##,###.00");
        }
        catch
        {
            return "";
        }
    }

    public static string fixRad(string strInput)
    {
        if (strInput == null)
            return "";

        // Replace strong tags with b tags...
        strInput = Regex.Replace(strInput, "strong", "b");
        // Replace slashes
        strInput = strInput.Replace("\\", "\\\\");
        // Replace quotes
        strInput = strInput.Replace("'", "''").Trim();

        return strInput;
    }
   
    
}

