﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace sam
{
    public partial class aircraft_availability : System.Web.UI.Page
    {
        private DbInterface db = new DbInterface();
        protected Admin_User Usr = new Admin_User();
        string sql = string.Empty;
        MySql.Data.MySqlClient.MySqlCommand cmd = null;
        MySqlDataReader dr = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            hideMenu();
            FillGrid();
        }


        private void FillGrid()
        {

            StringBuilder sb = new StringBuilder();
            try
            {

                sql = "SELECT fld_id,fld_aircraft_name,fld_manufacturing_year,"+
                    " fld_hours,"+
                    " case fld_status when '1' then '<font color=Green>Yes</font>'  when '2' then '<font color=Red>No</font>' end as availability," +
                    " fld_status " +
                    " FROM table_aircraft_models;";
                cmd = new MySqlCommand(sql);
                dr = db.Read(cmd);
                sb.Append("<table id=\"tblInfo\" class=\"table table-striped table-bordered calwidth\" cellspacing=\"0\" >" +
                "<thead>" +
                 "<tr>" +
                    "<th>AIRCRAFT NAME</th>" +                   
                    "<th>AVAILABILITY</th>" +
                "</tr>" +
                "</thead>" +
                "<tbody>");

                bool flag = false;
                while (dr.Read())
                {
                    flag = true;
                    sb.Append("<tr>")
                    .Append("" +
                    "<td style=\"padding-left:8px;\">" + dr["fld_aircraft_name"].ToString() + "</td>" +
                    "<td style=\"padding-left:8px;\">" + dr["availability"].ToString() + "</td>" +                   
                    "</tr>");
                }
                dr.Close();
                sb.Append("</tbody></table>");

                if (!flag)
                {
                    sb = new StringBuilder();
                    sb.Append("<h3 align=\"center\" style=\"colour:red\" >No record found.</h3>");
                }

                lbl_Grid.Text = sb.ToString();

            }
            finally
            {
                db.Close();
            }

        }


        private void hideMenu()
        {
            HtmlGenericControl li_aircraft_info = (HtmlGenericControl)Master.FindControl("li_aircraft_info");
            HtmlGenericControl li_fee_info = (HtmlGenericControl)Master.FindControl("li_fee_info");
            HtmlGenericControl li_aircraft_availability = (HtmlGenericControl)Master.FindControl("li_aircraft_availability");
            HtmlGenericControl li_trainer_information = (HtmlGenericControl)Master.FindControl("li_trainer_information");            
            HtmlGenericControl li_aircraft_login = (HtmlGenericControl)Master.FindControl("li_aircraft_login");
            HtmlGenericControl li_aircraft_logout = (HtmlGenericControl)Master.FindControl("li_aircraft_logout");

            li_aircraft_info.Visible = true;
            li_fee_info.Visible = true;
            li_aircraft_availability.Visible = true;
            li_trainer_information.Visible = true;
            li_aircraft_login.Visible = false;
            li_aircraft_logout.Visible = true;
        }
    }
}