﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace sam
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            hideMenu();
        }

        private void hideMenu()
        {
            HtmlGenericControl li_aircraft_info = (HtmlGenericControl)Master.FindControl("li_aircraft_info");
            HtmlGenericControl li_fee_info = (HtmlGenericControl)Master.FindControl("li_fee_info");
            HtmlGenericControl li_aircraft_availability = (HtmlGenericControl)Master.FindControl("li_aircraft_availability");
            HtmlGenericControl li_trainer_information = (HtmlGenericControl)Master.FindControl("li_trainer_information");   
            HtmlGenericControl li_aircraft_login = (HtmlGenericControl)Master.FindControl("li_aircraft_login");
            HtmlGenericControl li_aircraft_logout = (HtmlGenericControl)Master.FindControl("li_aircraft_logout");
           
            li_aircraft_info.Visible = false;
            li_fee_info.Visible = false;
            li_aircraft_availability.Visible = false;
            li_trainer_information.Visible = false;
            li_aircraft_login.Visible = true;
            li_aircraft_logout.Visible = false;
        }
    }
}