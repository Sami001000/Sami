﻿# Host: localhost  (Version: 5.1.50-community)
# Date: 2021-12-27 13:40:46
# Generator: MySQL-Front 5.3  (Build 2.30)

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;

DROP DATABASE IF EXISTS `sam`;
CREATE DATABASE `sam` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `sam`;

#
# Source for table "table_aircraft_models"
#

DROP TABLE IF EXISTS `table_aircraft_models`;
CREATE TABLE `table_aircraft_models` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_aircraft_name` varchar(255) DEFAULT NULL,
  `fld_manufacturing_year` int(11) DEFAULT NULL,
  `fld_hours` int(11) DEFAULT NULL,
  `fld_status` int(11) DEFAULT NULL,
  `fld_contract` int(11) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for table "table_aircraft_models"
#

INSERT INTO `table_aircraft_models` VALUES (1,'CESSNA 152',2007,80,1,0),(2,'CESSNA 172',2009,60,2,0),(3,'PA     28 -161',2013,50,1,0),(4,'PA     28 -181',2019,20,1,0),(5,'PIPER PA 28 R',2017,30,1,0);

#
# Source for table "table_contract"
#

DROP TABLE IF EXISTS `table_contract`;
CREATE TABLE `table_contract` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_contract` varchar(255) DEFAULT NULL,
  `fld_aircraft_id` varchar(255) DEFAULT NULL,
  `fld_fee` int(11) DEFAULT NULL,
  `fld_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

#
# Data for table "table_contract"
#

INSERT INTO `table_contract` VALUES (1,'Week days (MondayMonday-Friday)','3,2,1,0,,,',100,1),(2,'Week end (Saturday-Sunday)','4,0,',50,1),(3,'Monthly','0',350,1),(4,'Yearly','5,0,',3500,1);

#
# Source for table "table_fee_info"
#

DROP TABLE IF EXISTS `table_fee_info`;
CREATE TABLE `table_fee_info` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_air_craft_id` int(11) DEFAULT NULL,
  `fld_contract_id` int(11) DEFAULT NULL,
  `fld_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# Data for table "table_fee_info"
#

INSERT INTO `table_fee_info` VALUES (1,1,1,0),(2,2,1,0),(3,3,1,0),(4,4,2,0),(5,5,4,0),(6,1,2,0),(7,4,3,0),(8,1,1,0),(9,3,3,0),(10,2,3,1);

#
# Source for table "table_trainers"
#

DROP TABLE IF EXISTS `table_trainers`;
CREATE TABLE `table_trainers` (
  `fld_id` int(11) NOT NULL AUTO_INCREMENT,
  `fld_trainer_name` varchar(255) DEFAULT NULL,
  `fld_hours` int(11) DEFAULT NULL,
  `fld_licence_number` varchar(255) DEFAULT NULL,
  `fld_status` int(11) DEFAULT NULL,
  `fld_aircraft_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`fld_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for table "table_trainers"
#

INSERT INTO `table_trainers` VALUES (1,'Sam Cu',20,'AED-324',1,0),(2,'Joe Cu',25,'AET-467',0,2),(3,'Prajwin Cu',20,'HFG-585',1,0),(4,'Thomas Cu',15,'LUG-398',1,0),(5,'Prem Cu',10,'KIH-767',1,0);

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
